# Pull Request: Add Review Comment Analyzer

## Summary

Adds a reusable Review Comment Analyzer that helps developers organize AI-generated code review feedback. The feature validates review comments, filters them by severity, searches comment text, sorts findings by priority, and produces severity summaries.

## Changes

- Added `Severity` enum with Critical, High, Medium, and Low levels.
- Added an immutable `ReviewComment` data model with input validation.
- Added `ReviewCommentAnalyzer` for adding and removing comments.
- Added filtering by severity and case-insensitive text search.
- Added severity summaries, highest-severity detection, sorting, and clearing.
- Added unit tests covering validation, filtering, summaries, sorting, search, and removal.
- Added usage instructions in `README.md`.

## Context

AI-assisted code reviews can produce multiple findings with different levels of urgency. Developers need a simple way to identify critical issues first and navigate review feedback efficiently. This feature provides a small, independently testable utility for that workflow.

**Related issue:** Not specified.

**Implementation size:** The feature implementation is in `review_analyzer/analyzer.py` (approximately 100–200 lines, excluding tests and documentation).

**Testing:** Run `python3 -m unittest discover -s tests -v` from the project directory.
