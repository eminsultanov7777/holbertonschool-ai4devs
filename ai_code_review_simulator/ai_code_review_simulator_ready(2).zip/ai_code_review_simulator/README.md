# AI Code Review Simulator - Review Comment Analyzer

A small Python feature for organizing AI code-review feedback.

## Run tests

From this directory:

```bash
python3 -m unittest discover -s tests -v
```

## Example

```python
from review_analyzer import ReviewComment, ReviewCommentAnalyzer, Severity

analyzer = ReviewCommentAnalyzer([
    ReviewComment("Validate user input", Severity.HIGH),
    ReviewComment("Rename this variable", Severity.LOW),
])

print(analyzer.summary())
print(analyzer.filter_by_severity(Severity.HIGH))
```
