"""Utilities for organizing and prioritizing AI code-review comments."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from enum import Enum
from typing import Iterable, Optional


class Severity(str, Enum):
    """Supported code-review severity levels."""

    CRITICAL = "Critical"
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


@dataclass(frozen=True)
class ReviewComment:
    """A single review comment with a validated severity."""

    message: str
    severity: Severity

    def __post_init__(self) -> None:
        if not isinstance(self.message, str) or not self.message.strip():
            raise ValueError("Comment message must be a non-empty string.")
        if not isinstance(self.severity, Severity):
            raise ValueError("Severity must be a Severity enum value.")


class ReviewCommentAnalyzer:
    """Validate, filter, and summarize code-review comments."""

    def __init__(self, comments: Optional[Iterable[ReviewComment]] = None) -> None:
        self._comments: list[ReviewComment] = []
        if comments is not None:
            self.add_many(comments)

    @property
    def comments(self) -> tuple[ReviewComment, ...]:
        """Return an immutable snapshot of all stored comments."""
        return tuple(self._comments)

    def add(self, comment: ReviewComment) -> None:
        """Add one validated review comment."""
        if not isinstance(comment, ReviewComment):
            raise TypeError("Expected a ReviewComment instance.")
        self._comments.append(comment)

    def add_many(self, comments: Iterable[ReviewComment]) -> None:
        """Add multiple comments; reject invalid items without partial updates."""
        incoming = list(comments)
        if any(not isinstance(item, ReviewComment) for item in incoming):
            raise TypeError("All items must be ReviewComment instances.")
        self._comments.extend(incoming)

    def filter_by_severity(self, severity: Severity) -> list[ReviewComment]:
        """Return comments matching the requested severity."""
        if not isinstance(severity, Severity):
            raise ValueError("Unsupported severity.")
        return [item for item in self._comments if item.severity is severity]

    def summary(self) -> dict[str, int]:
        """Return a count for every severity, including levels with zero items."""
        counts = Counter(item.severity.value for item in self._comments)
        return {level.value: counts[level.value] for level in Severity}

    def highest_severity(self) -> Optional[Severity]:
        """Return the highest severity present, or None when there are no comments."""
        order = (
            Severity.CRITICAL,
            Severity.HIGH,
            Severity.MEDIUM,
            Severity.LOW,
        )
        present = {item.severity for item in self._comments}
        return next((level for level in order if level in present), None)

    def remove(self, comment: ReviewComment) -> bool:
        """Remove the first matching comment; return False if it is absent."""
        try:
            self._comments.remove(comment)
        except ValueError:
            return False
        return True

    def clear(self) -> None:
        """Remove all comments."""
        self._comments.clear()

    def search(self, phrase: str) -> list[ReviewComment]:
        """Find comments containing a case-insensitive phrase."""
        if not isinstance(phrase, str) or not phrase.strip():
            raise ValueError("Search phrase must be a non-empty string.")
        needle = phrase.casefold()
        return [item for item in self._comments if needle in item.message.casefold()]

    def sort_by_severity(self) -> list[ReviewComment]:
        """Return comments ordered Critical, High, Medium, then Low."""
        rank = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
        }
        return sorted(self._comments, key=lambda item: rank[item.severity])

    def total(self) -> int:
        """Return the number of stored comments."""
        return len(self._comments)
