import unittest

from review_analyzer import ReviewComment, ReviewCommentAnalyzer, Severity


class ReviewCommentAnalyzerTests(unittest.TestCase):
    def setUp(self):
        self.comments = [
            ReviewComment("SQL injection risk", Severity.CRITICAL),
            ReviewComment("Missing input validation", Severity.HIGH),
            ReviewComment("Consider clearer naming", Severity.LOW),
            ReviewComment("Potential race condition", Severity.MEDIUM),
            ReviewComment("Another high priority issue", Severity.HIGH),
        ]
        self.analyzer = ReviewCommentAnalyzer(self.comments)

    def test_add_and_total(self):
        self.analyzer.add(ReviewComment("Improve logging", Severity.LOW))
        self.assertEqual(self.analyzer.total(), 6)

    def test_reject_invalid_message(self):
        with self.assertRaises(ValueError):
            ReviewComment("   ", Severity.LOW)

    def test_reject_invalid_severity(self):
        with self.assertRaises(ValueError):
            ReviewComment("Bad severity", "Urgent")

    def test_filter_by_severity(self):
        results = self.analyzer.filter_by_severity(Severity.HIGH)
        self.assertEqual(len(results), 2)
        self.assertTrue(all(item.severity is Severity.HIGH for item in results))

    def test_summary_includes_zero_counts(self):
        summary = self.analyzer.summary()
        self.assertEqual(summary["Critical"], 1)
        self.assertEqual(summary["High"], 2)
        self.assertEqual(summary["Medium"], 1)
        self.assertEqual(summary["Low"], 1)

    def test_highest_severity(self):
        self.assertIs(self.analyzer.highest_severity(), Severity.CRITICAL)

    def test_highest_severity_empty(self):
        self.assertIsNone(ReviewCommentAnalyzer().highest_severity())

    def test_search_is_case_insensitive(self):
        self.assertEqual(len(self.analyzer.search("SQL")), 1)

    def test_search_rejects_empty_phrase(self):
        with self.assertRaises(ValueError):
            self.analyzer.search(" ")

    def test_sort_by_severity(self):
        ordered = self.analyzer.sort_by_severity()
        self.assertEqual(ordered[0].severity, Severity.CRITICAL)
        self.assertEqual(ordered[-1].severity, Severity.LOW)

    def test_remove_and_clear(self):
        target = self.comments[0]
        self.assertTrue(self.analyzer.remove(target))
        self.assertFalse(self.analyzer.remove(target))
        self.analyzer.clear()
        self.assertEqual(self.analyzer.total(), 0)

    def test_add_many_is_atomic_for_invalid_items(self):
        before = self.analyzer.total()
        with self.assertRaises(TypeError):
            self.analyzer.add_many([
                ReviewComment("Valid", Severity.LOW),
                "not a comment",
            ])
        self.assertEqual(self.analyzer.total(), before)


if __name__ == "__main__":
    unittest.main()
